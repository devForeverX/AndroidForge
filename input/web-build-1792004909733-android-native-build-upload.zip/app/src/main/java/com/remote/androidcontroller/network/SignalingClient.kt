package com.remote.androidcontroller.network

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

interface SignalingListener {
    fun onConnected()
    fun onDisconnected()
    fun onMessageReceived(message: BaseMessage)
    fun onError(reason: String)
}

class SignalingClient(
    private val serverUrl: String,
    private val listener: SignalingListener
) {
    private val client = OkHttpClient.Builder()
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var webSocket: WebSocket? = null
    private var reconnectJob: Job? = null
    private var heartbeatJob: Job? = null

    private var currentBackoffMs = 1000L
    private val maxBackoffMs = 30000L
    private var shouldReconnect = true

    fun connect() {
        shouldReconnect = true
        if (!scope.isActive) {
            scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        }
        initiateConnection()
    }

    private fun initiateConnection() {
        val request = Request.Builder()
            .url(serverUrl)
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                currentBackoffMs = 1000L
                startHeartbeat()
                listener.onConnected()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val baseMessage = ProtocolJson.json.decodeFromString<BaseMessage>(text)
                    listener.onMessageReceived(baseMessage)
                } catch (e: Exception) {
                    listener.onError("Parsing error: ${e.message}")
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(code, reason)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                stopHeartbeat()
                listener.onDisconnected()
                triggerReconnect()
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                stopHeartbeat()
                listener.onError("Connection failure: ${t.message}")
                listener.onDisconnected()
                triggerReconnect()
            }
        })
    }

    fun sendMessage(message: BaseMessage): Boolean {
        val json = ProtocolJson.json.encodeToString(message)
        return webSocket?.send(json) ?: false
    }

    private fun startHeartbeat() {
        stopHeartbeat()
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(15000)
                val ping = ProtocolJson.createMessage(
                    type = MessageType.PING,
                    payload = kotlinx.serialization.json.JsonObject(emptyMap())
                )
                sendMessage(ping)
            }
        }
    }

    private fun stopHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = null
    }

    private fun triggerReconnect() {
        if (!shouldReconnect) return

        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(currentBackoffMs)
            currentBackoffMs = (currentBackoffMs * 2).coerceAtMost(maxBackoffMs)
            if (shouldReconnect) {
                initiateConnection()
            }
        }
    }

    fun disconnect() {
        shouldReconnect = false
        stopHeartbeat()
        reconnectJob?.cancel()
        webSocket?.close(1000, "Normal closure")
        webSocket = null
        scope.cancel()
    }
}
