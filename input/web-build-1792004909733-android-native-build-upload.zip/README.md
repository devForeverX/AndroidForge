# Native Android Phone Remote Control App

Vollständig natives Android-Studio-Projekt in Kotlin mit Jetpack Compose zur dauerhaften Koppelung und Fernsteuerung zwischen zwei Android-Smartphones.

---

## 1. Systemvoraussetzungen & Build-Spezifikation

- **Android Studio**: Hedgehog (2023.1.1), Iguana, Ladybug, Koala oder neuer.
- **Gradle**: 8.7 (über mitgelieferten Gradle Wrapper `./gradlew`).
- **Android Gradle Plugin (AGP)**: 8.7.1.
- **Kotlin**: 2.0.21 (Compose Compiler 2.0).
- **JDK**: Java 17 oder 21.
- **Mindestversion (minSdk)**: API 26 (Android 8.0 Oreo).
- **Zielversion (targetSdk & compileSdk)**: API 35 (Android 15).

---

## 2. Projektstruktur

```
android/
├── app/
│   ├── build.gradle.kts           // Abhängigkeiten: Compose, WebRTC, OkHttp, Security
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml // Services, Permissions, Intent-Filter
│       │   ├── java/com/remote/androidcontroller/
│       │   │   ├── RemoteApp.kt
│       │   │   ├── MainActivity.kt
│       │   │   ├── crypto/         // KeystoreManager (AES-256-GCM), PairingManager (HKDF)
│       │   │   ├── network/        // WebRtcPeerManager, SignalingClient, Protocol.kt
│       │   │   ├── audio/          // AudioPacket (Binary), JitterBuffer, AudioStreamEngine
│       │   │   ├── services/       // AccessibilityService, RemoteInputMethodService, FGS
│       │   │   ├── ui/             // Material 3 Compose Screens & AndroidNavigationBar
│       │   │   └── viewmodel/      // RemoteControlViewModel (MVVM StateFlow)
│       │   └── res/                // Strings, Farben, Themes, Accessibility & IME XMLs
│       └── test/                   // Unit Tests für Krypto, Protokoll & Jitter Buffer
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

---

## 3. Kompilierung & Installation

### APK bauen (Debug)
```bash
cd android
./gradlew assembleDebug
```
Die erzeugte APK liegt unter:
`app/build/outputs/apk/debug/app-debug.apk`

### Unit-Tests ausführen
```bash
./gradlew test
```

### Installation auf zwei Android-Geräten via ADB
```bash
# Erstes Smartphone (Admin-Controller)
adb -s <DEVICE_ID_1> install -r app/build/outputs/apk/debug/app-debug.apk

# Zweites Smartphone (Remote-Zielgerät)
adb -s <DEVICE_ID_2> install -r app/build/outputs/apk/debug/app-debug.apk
```

---

## 4. Berechtigungen & Einrichtung auf dem Remote-Zielgerät

Damit das Zielgerät die Befehle des Admin-Smartphones im System ausführen kann, müssen folgende offizielle Android-Dienste einmalig aktiviert werden:

1. **Bedienungshilfen-Dienst (Accessibility Service)**:
   - Einstellungen $\rightarrow$ Bedienungshilfen (Accessibility) $\rightarrow$ Installierte Apps / Dienste $\rightarrow$ **Remote Control Navigation Service** auf **AN** schalten.
   - *Funktion*: Ausführen der globalen Tasten **Zurück**, **Home** und **Recent Apps**.
2. **Eingabemethode (Remote Input Method Service / IME)**:
   - Einstellungen $\rightarrow$ System $\rightarrow$ Sprachen & Tastatur $\rightarrow$ Bildschirmtastatur $\rightarrow$ Tastaturen verwalten $\rightarrow$ **Remote Control Tastatur (IME)** aktivieren und bei Bedarf auswählen.
   - *Funktion*: Direktes Einfügen von Text via `currentInputConnection.commitText` in fokussierte Eingabefelder.
3. **Systemeinstellungen ändern (Helligkeit)**:
   - In der App im Tab *Rechte* auf *Berechtigung erteilen* tippen $\rightarrow$ In den Android-Systemeinstellungen **Systemeinstellungen ändern** erlauben.
4. **Hintergrundbetrieb & Benachrichtigungen**:
   - Für dauerhaftes Audio-Streaming wird der offizielle Foreground Service `mediaPlayback` mit transparenter Statusbenachrichtigung genutzt.

---

## 5. Kopplung & Verbindungsaufbau

1. Öffne die App auf beiden Smartphones.
2. Wähle auf Gerät 1 **Admin-Gerät (Controller)**.
3. Wähle auf Gerät 2 **Remote-Gerät (Zielgerät)**.
4. Admin tippt auf **Neues Gerät koppeln** $\rightarrow$ Ein 6-stelliger Einmal-Code wird angezeigt.
5. Zielgerät tippt den 6-stelligen Code ein.
6. Beide Geräte führen einen kryptografisch an den Code gebundenen ECDH-Handshake durch und zeigen den identischen **SAS-Verifikationscode** an.
7. Bestätige auf beiden Geräten. Die Bindung wird verschlüsselt im `AndroidKeyStore` gesichert und bleibt über Neustarts erhalten.
